from django.apps import AppConfig


class ResoappConfig(AppConfig):
    name = 'resoapp'
